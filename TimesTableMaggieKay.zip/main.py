# ask the user for a number
num = int(input("Enter a number: "))

# initialize counter
count = 0

# multiply through the numbers from 0 to 10
while (count <= 10):
  print(str(count) + "*" + str(num) + "=" + str(count * num))
  count = count + 1